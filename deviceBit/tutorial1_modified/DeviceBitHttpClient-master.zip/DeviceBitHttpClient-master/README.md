DeviceBitHttpClient
===================

arduino library,enable your sensors and devices talking to devicebit.com via HTTP method
