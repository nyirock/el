BH1750FVI_Master
================

Digital Light Sensor BH1750 

/*
  This is a simple code to test BH1750FVI Light senosr
  
  communicate using I2C Protocol 
  
  this library enable 2 slave device address
  
  Main address  0x23 
  
  secondary address 0x5C 
  
  connect this sensor as following :
  
  VCC >>> 3.3V
  
  SDA >>> A4 
  
  SCL >>> A5
  
  addr >> A3 "Optional and use address 0x23 "
  
  Gnd >>>Gnd



  please after download this library unzip and rename it to BH1750FVI and put it in the libraries folder in the arduino path , then restart Arduino IDE
  
  
  Written By : Mohannad Rawashdeh
  
  26/9/2013
  
  for more information : http://www.instructables.com/id/BH1750-Digital-Light-Sensor/
  
  contact me on my email
  
  genotronex@gmail.com
 */
 
