'''
Created on 7 Dec 2012

@author: Jamie
'''
from tweeter import tweeter

myTweeter = tweeter()
print myTweeter.tweet("I Love My Gash Twitter Library")

