'''
Created on 8 Dec 2012

@author: Jamie
'''
from distutils.core import setup
setup(name='tweeter',
      version='0.0.4',
      description='Twitter Wrapper',
      author='Jamie Jackson',
      author_email='jamie@jacobean.net',
      url='http://blog.jacobean.net',
      py_modules=['tweeter'],
      )