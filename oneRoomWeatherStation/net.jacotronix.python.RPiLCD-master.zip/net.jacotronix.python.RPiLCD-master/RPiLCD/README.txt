RaspberryPi LCD Display Drivers

RPiCharLCD:

	Class to drive a 2 line 1602 HD44780 LCD Module
	
	The vast majority of this code comes from :
	
	HD44780 LCD Test Script for Raspberry Pi by Matt Hawkins
	http://www.raspberrypi-spy.co.uk
	
History
-------

0.0.1	28 Dec 12	First release version of RPiCharLCD