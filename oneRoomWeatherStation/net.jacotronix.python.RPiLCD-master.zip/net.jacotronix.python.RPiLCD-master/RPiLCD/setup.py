'''
Created on 8 Dec 2012

@author: Jamie
'''
from distutils.core import setup
setup(name='RPiLCD',
      version='0.0.1',
      description='RaspberryPi LCD Display Drivers',
      author='Jamie Jackson',
      author_email='jamie@jacobean.net',
      url='http://blog.jacobean.net',
      py_modules=['RPiCharLCD'],
      )