Daemon Wrapper

Code from this from Sander Marechal's �A simple unix/linux daemon in Python"
http://www.jejik.com/articles/2007/02/a_simple_unix_linux_daemon_in_python/

0.0.1	27 Dec 12	Wrapper for Unix style Daemon processes