
from distutils.core import setup
setup(name='daemon',
      version='0.0.1',
      description='Daemon Wrapper',
      maintainer='Jamie Jackson',
      maintainer_email='jamie@jacobean.net',
      url='http://blog.jacobean.net',
      py_modules=['daemon'],
      )