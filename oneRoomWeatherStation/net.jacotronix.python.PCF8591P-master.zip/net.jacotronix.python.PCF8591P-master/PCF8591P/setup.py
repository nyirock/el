'''
Created on 9 Dec 2012

@author: Jamie
'''
from distutils.core import setup
setup(name='PCF8591P',
      version='0.0.3',
      description='PCF8591P Class',
      maintainer='Jamie Jackson',
      maintainer_email='jamie@jacobean.net',
      url='http://blog.jacobean.net',
      py_modules=['PCF8591P'],
      )