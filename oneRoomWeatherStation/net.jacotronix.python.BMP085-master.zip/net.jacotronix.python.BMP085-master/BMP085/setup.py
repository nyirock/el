
from distutils.core import setup
setup(name='BMP085',
      version='0.0.1',
      description='i2C BMP085 Pressure & Temperature Sensor Driver',
      maintainer='Jamie Jackson',
      maintainer_email='jamie@jacobean.net',
      url='http://blog.jacobean.net',
      py_modules=['BMP085'],
      )