i2C BMP085 Pressure & Temperature Sensor Driver

Code for this is mainly referenced from these 2 sources:

Maarten Damen�s Bus Pirate reading the BMP085 Temperature
http://www.maartendamen.com/2011/04/bus-pirate-reading-bmp085-temperature/

Python port of John Burn�s C Code in Reading data from a Bosch BMP085 with a Raspberry Pi
http://www.john.geek.nz/2012/08/reading-data-from-a-bosch-bmp085-with-a-raspberry-pi/

History
-------

0.0.1	27 Dec 12	Initial Version